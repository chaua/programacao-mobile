import 'package:flutter/material.dart';

import '../../shared/models/pokemon.dart';
import 'widget/detalhes_pokemon_conteudo.dart';

// Tela de