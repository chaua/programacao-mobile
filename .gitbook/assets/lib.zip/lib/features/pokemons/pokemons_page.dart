import 'package:flutter/material.dart';

import '../../app/app_routes.dart';
import '../../shared/models/pokemon.dart';
import 'widget/pokemon_card.dart';

// TODO ALUNO: Criar a tela para mostrar a lista de pokemons