import 'package:flutter/material.dart';

// TODO ALUNO: Criar a conteudo da tela de detalhes do Pokemon mostrando seus atributos