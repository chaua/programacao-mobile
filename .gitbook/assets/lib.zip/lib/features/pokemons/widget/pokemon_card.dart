import 'package:flutter/material.dart';

import '../../../shared/models/pokemon.dart';

// TODO ALUNO: Criar o card para aparecer na lista de pokemons