class Pokemon {
  final String nome;
  final String tipo;
  final String habilidade;
  final String descricao;
  final String urlImagem;

  const Pokemon({
    required this.nome,
    required this.tipo,
    required this.habilidade,
    required this.descricao,
    required this.urlImagem,
  });
}

// TODO ALUNO: esta é a entidade da nova funcionalidade.
// Altere, adicione ou remova atributos se a sua tela de Pokémon precisar
// mostrar outras informações, como número da Pokédex, altura ou peso.
const List<Pokemon> pokemonsFake = [
  Pokemon(
    nome: 'Pikachu',
    tipo: 'Elétrico',
    habilidade: 'Choque do Trovão',
    descricao:
        'Pokémon elétrico ágil, conhecido por armazenar energia nas bochechas e liberar descargas fortes em batalha.',
    urlImagem: 'https://picsum.photos/seed/pokemon-pikachu/800/600',
  ),
  Pokemon(
    nome: 'Charmander',
    tipo: 'Fogo',
    habilidade: 'Chama',
    descricao:
        'Pokémon do tipo fogo com uma chama na ponta da cauda. É determinado e cresce muito em batalhas difíceis.',
    urlImagem: 'https://picsum.photos/seed/pokemon-charmander/800/600',
  ),
  Pokemon(
    nome: 'Bulbasaur',
    tipo: 'Grama e veneno',
    habilidade: 'Crescimento Natural',
    descricao:
        'Pokémon com uma semente nas costas, capaz de absorver energia solar e usar ataques baseados em plantas.',
    urlImagem: 'https://picsum.photos/seed/pokemon-bulbasaur/800/600',
  ),
  Pokemon(
    nome: 'Squirtle',
    tipo: 'Água',
    habilidade: 'Jato de Água',
    descricao:
        'Pokémon aquático protegido por um casco resistente. Usa água pressurizada para atacar e se defender.',
    urlImagem: 'https://picsum.photos/seed/pokemon-squirtle/800/600',
  ),
  Pokemon(
    nome: 'Eevee',
    tipo: 'Normal',
    habilidade: 'Evolução Adaptável',
    descricao:
        'Pokémon com grande capacidade de adaptação, famoso por poder evoluir para diferentes formas especiais.',
    urlImagem: 'https://picsum.photos/seed/pokemon-eevee/800/600',
  ),
  Pokemon(
    nome: 'Snorlax',
    tipo: 'Normal',
    habilidade: 'Descanso Pesado',
    descricao:
        'Pokémon calmo e muito resistente. Passa boa parte do dia dormindo, mas pode bloquear caminhos inteiros.',
    urlImagem: 'https://picsum.photos/seed/pokemon-snorlax/800/600',
  ),
];
